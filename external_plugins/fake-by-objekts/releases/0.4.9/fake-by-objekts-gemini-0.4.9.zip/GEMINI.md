# FAKE by objekts

Read skills/character-authoring/SKILL.md before character authoring. Use the live MCP at https://fake.objekts.ai/mcp. Image generation requires a tool supplied by the current host. Do not promise ChatGPT image generation in another client. Preserve Character State, locks and explicit Master selection.
